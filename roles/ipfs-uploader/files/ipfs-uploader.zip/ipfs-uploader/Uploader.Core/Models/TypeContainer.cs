namespace Uploader.Core.Models
{
    internal enum TypeContainer
    {
        Undefined,
        Video,
        Overlay,
        Subtitle
    }
}