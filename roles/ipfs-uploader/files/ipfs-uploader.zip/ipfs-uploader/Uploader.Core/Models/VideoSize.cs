namespace Uploader.Core.Models
{
    internal enum VideoSize
    {
        Undefined,
        Source,
        F240p,
        F360p,
        F480p,
        F720p,
        F1080p
    }
}