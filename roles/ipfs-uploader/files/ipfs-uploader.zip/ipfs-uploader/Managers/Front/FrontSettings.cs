namespace Uploader.Managers.Front
{
    public class FrontSettings
    {
        /// <summary>
        /// seconds
        /// </summary>
        public static int MaxGetProgressCanceled => 20;

        public static string ImageMagickPath => @"";
    }
}
