namespace Uploader.Models
{
    public enum TypeFile
    {
        Undefined,
        SourceVideo,
        EncodedVideo,
        SpriteVideo,
        SourceImage,
        OverlayImage
    }
}