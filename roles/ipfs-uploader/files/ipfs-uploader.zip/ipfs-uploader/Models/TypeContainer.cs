namespace Uploader.Models
{
    public enum TypeContainer
    {
        Undefined,
        Video,
        Overlay
    }
}