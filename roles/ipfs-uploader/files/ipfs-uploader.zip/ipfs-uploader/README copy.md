# ipfs-uploader
Files manipulation and adds to IPFS gracefully
